#REPOsitory.XvBMC
 
NOTE: XvBMC Nederland (xbmc nl) wij zijn géén helpdesk van/voor boxverkopers
 
  
   
#XvBMC_Nederland:
http://bit.ly/XvBMC-NL | https://www.fb.com/groups/XvBMCnederland/
 
#XvBMC_Pi:
http://bit.ly/XvBMC-Pi | https://www.fb.com/groups/XbmcVoorBeginnersRaspberryPi/
 
#XvBMC_Android:
http://bit.ly/XvBMC-Android | https://www.fb.com/groups/xbmcvoorbeginners.android/
 
#XvBMC_FilmsSeriesMuziek:
http://bit.ly/XvBMC-Media | https://www.fb.com/groups/XbmcvoorbeginnersfilmsForum/
 
#XvBMC_Sports:
http://bit.ly/XvBMC-Sport | https://www.fb.com/groups/XbmcVoorBeginnersSportChat/
 
#XvBMC_retro-Games         |                  .:C.T.R.L:. Gaming Room [NL] :
http://bit.ly/XvBMC-Gaming | https://www.facebook.com/groups/ctrlgamingroom/
 
#XvBMC_YouTube:
http://bit.ly/XvBMC-YouTube | https://www.youtube.com/user/onlinefilmskijken/
   
  
 
With kind regards, 
Team X(v)BMC Nederland 
 
  
© Copyright XvBMC 2015-2020. Alle rechten voorbehouden. Tenzij anders vermeld berusten alle rechten op informatie (tekst, beeld, geluid, video, addons, code, repository, etc) die u op deze site (github en alle onderliggende pagina’s) aantreft bij XvBMC of zijn gelicenceerd aan XvBMC.
 
Gehele of gedeeltelijke overname, plaatsing op andere sites, verveelvoudiging op welke andere wijze dan ook en/of commercieel gebruik van deze informatie is niet toegestaan, tenzij hiervoor uitdrukkelijk schriftelijke toestemming is verleend door XvBMC of tenzij aan de onderstaande voorwaarden wordt voldaan.
 
Deze informatie mag worden bekeken op een scherm, gedownload worden op een hard-disk of geprint worden, mits dit geschied voor persoonlijk, informatief en niet-commercieel gebruik, mits de informatie niet gewijzigd wordt, mits de volgende copyright-tekst in elke copy aanwezig is: “© Copyright XvBMC Nederland”, mits copyright, handelsmerk en andere van toepassing zijnde teksten niet worden verwijderd en mits de informatie niet wordt gebruikt in een ander werk of publicatie in welk medium dan ook.
 
XvBMC voert het beheer over de pagina’s op deze website. Het linken en verwijzen naar de pagina’s op deze website is toegestaan. De webmaster stelt het op prijs hiervan in kennis te worden gesteld.
 